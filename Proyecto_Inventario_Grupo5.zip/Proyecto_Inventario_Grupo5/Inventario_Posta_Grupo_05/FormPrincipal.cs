﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventario_Posta_Grupo_05
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
            FormInicio formInicio = new FormInicio();
            abrirForm(formInicio);
        }

        private void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        void abrirForm(Form form)
        {
            while (panelBasePrincipal.Controls.Count > 0)
            {
                panelBasePrincipal.Controls.RemoveAt(0);
            }

            Form formHijo = form;
            form.TopLevel = false;
            formHijo.FormBorderStyle = FormBorderStyle.None;
            formHijo.Dock = DockStyle.Fill;
            panelBasePrincipal.Controls.Add(formHijo);
            formHijo.Show();
        }

        private void btnInicio_Click(object sender, EventArgs e)
        {
            FormInicio formInicio = new FormInicio();
            abrirForm(formInicio);
        }

        private void btnAdministrador_Click(object sender, EventArgs e)
        {
            FormEmpleado formEmpleado = new FormEmpleado();
            abrirForm(formEmpleado);
        }

        private void btnInventario_Click(object sender, EventArgs e)
        {
            FormInventario formInventario = new FormInventario();
            abrirForm(formInventario);
        }
    }
}
