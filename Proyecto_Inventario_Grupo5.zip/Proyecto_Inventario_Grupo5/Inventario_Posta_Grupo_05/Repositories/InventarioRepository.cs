﻿using Inventario_Posta_Grupo_05.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventario_Posta_Grupo_05.Repositories
{
    class InventarioRepository
    {
        private static List<Inventario> inventarios = new List<Inventario>();

        public bool Existe(int codigoInventario)
        {
            return inventarios.Exists(i => i.Codigo.Equals(codigoInventario));
        }

        public void Registrar(Inventario inventario)
        {
            inventarios.Add(inventario);
        }

        public static List<Inventario> ListarTodo()
        {
            return inventarios;
        }

        public Inventario BuscarInventarioPorCodigo(int codigoInventario)
        {
            return inventarios.FirstOrDefault(i => i.Codigo == codigoInventario);
        }
    }
}
