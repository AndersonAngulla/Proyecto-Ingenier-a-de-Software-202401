﻿using Inventario_Posta_Grupo_05.Entities;
using Inventario_Posta_Grupo_05.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventario_Posta_Grupo_05
{
    public partial class FormInventario : Form
    {
        private InventarioService inventarioService = new InventarioService();

        public FormInventario()
        {
            InitializeComponent();
            MostrarInventarios(inventarioService.ListarTodo());
        }

        private void MostrarInventarios(List<Inventario> inventarios)
        {
            dgListaInventarios.DataSource = null;
            if(inventarios.Count == 0)
            {
                return;
            }
            else
            {
                dgListaInventarios.DataSource = inventarios;
            }
        }

        private void LimpiarCampos()
        {
            tbCodigo.Clear();
            tbNombre.Clear();
            tbStock.Clear();
            tbProveedor.Clear();
            dtFechaEntrada.Value = DateTime.Now;
        }

        private void btnLimpiarCampos_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void btnRegistrarInventario_Click(object sender, EventArgs e)
        {
            if(tbCodigo.Text == "" || tbNombre.Text == "" || tbStock.Text == "" || tbProveedor.Text == "")
            {
                MessageBox.Show("Por favor completar todos los campos", "Advertencia: Campo vacios", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if(!int.TryParse(tbCodigo.Text, out int codigo))
            {
                MessageBox.Show("Se ha ingresado incorrectamente el campo Codigo", "Error: Campo Codigo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(tbStock.Text, out int stock))
            {
                MessageBox.Show("Se ha ingresado incorrectamente el campo Stock", "Error: Campo Stock", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            bool contieneNumeroNombre = false;

            foreach (char caracter in tbNombre.Text)
            {
                if (char.IsDigit(caracter))
                {
                    contieneNumeroNombre = true;
                    break;
                }
            }

            if (contieneNumeroNombre)
            {
                MessageBox.Show("Se ha ingresado incorrectamente el campo Nombre", "Error: Campo Nombre", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Inventario inventario = new Inventario()
            {
                Codigo = int.Parse(tbCodigo.Text),
                Nombre = tbNombre.Text,
                Stock = int.Parse(tbStock.Text),
                Proveedor = tbProveedor.Text,
                FechaEntrada = dtFechaEntrada.Value.Date,
                Productos = new List<Producto>(),
            };

            bool registrado = inventarioService.Registrar(inventario);
            if (!registrado)
            {
                MessageBox.Show("Se ha ingresado un código de inventario ya existente", "Error: Codigo Existente", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MostrarInventarios(inventarioService.ListarTodo());
            LimpiarCampos();
        }

        private void btnVerProductos_Click(object sender, EventArgs e)
        {
            if(dgListaInventarios.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor seleccionar un inventario del cual desea ver los productos", "Advertencia: Ver Productos", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            String codigoInventario = dgListaInventarios.SelectedRows[0].Cells[0].Value.ToString();

            FormProducto formProducto = new FormProducto(int.Parse(codigoInventario));
            formProducto.Show();
        }

        private void LimpiarCamposBuscar()
        {
            tbCodigoBuscar.Clear();
        }

        private void btnBuscarCodigo_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbCodigoBuscar.Text))
            {
                MessageBox.Show("Por favor completar todos los campos", "Advertencia: Campos Vacios", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            int codigoABuscar;
            if (!int.TryParse(tbCodigoBuscar.Text, out codigoABuscar))
            {
                MessageBox.Show("El codigo del inventario debe ser un número entero válido", "Error: Codigo Inventario Buscar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Inventario inventarioEncontrado = inventarioService.BuscarInventarioPorCodigo(codigoABuscar);
            
            if (inventarioEncontrado != null)
            {
                ActualizarDataGridViewBusqueda(inventarioEncontrado);
                LimpiarCamposBuscar();
            }
            else
            {
                MessageBox.Show("El codigo del inventario solicitado no se encuentra registrado", "Información: Codigo Inventario Buscar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        private void ActualizarDataGridViewBusqueda(Inventario inventario)
        {
            dgListaInventarios.DataSource = null;
            List<Inventario> inventarioEncontrados = new List<Inventario>();
            inventarioEncontrados.Add(inventario);
            dgListaInventarios.DataSource = inventarioEncontrados;
        }
    }
}
