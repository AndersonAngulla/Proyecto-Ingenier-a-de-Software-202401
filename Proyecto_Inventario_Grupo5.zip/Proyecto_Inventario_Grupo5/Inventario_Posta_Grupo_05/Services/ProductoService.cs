﻿using Inventario_Posta_Grupo_05.Entities;
using Inventario_Posta_Grupo_05.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventario_Posta_Grupo_05.Services
{
    class ProductoService
    {
        private ProductoRepository productoRepository = new ProductoRepository();
        public bool Registrar(int codigoInventario, Producto producto)
        {
            if (productoRepository.Existe(producto.Codigo))
            {
                return false;
            }
            else
            {
                productoRepository.Registrar(codigoInventario, producto);
                return true;
            }
        }

        public List<Producto> ListarTodo(int codigoInventario)
        {
            return productoRepository.ListarTodo(codigoInventario);
        }

        public void Eliminar(int codigoProducto)
        {
            productoRepository.Eliminar(codigoProducto);
        }

        public void SalidaStock(int codigoProducto, int restarStock)
        {
            Producto productoEncontrado = productoRepository.BuscarPorCodigo(codigoProducto);

            if (productoEncontrado != null)
            {
                productoEncontrado.Stock -= restarStock;

                if (productoEncontrado.Stock < 0)
                {
                    throw new Exception("Stock insuficiente");
                }
            }
            else
            {
                throw new Exception("Producto no encontrado");
            }
        }
    }
}
