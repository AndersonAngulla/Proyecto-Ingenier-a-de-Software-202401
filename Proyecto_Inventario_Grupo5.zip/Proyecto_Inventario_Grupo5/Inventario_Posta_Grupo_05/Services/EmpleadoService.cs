﻿using Inventario_Posta_Grupo_05.Entities;
using Inventario_Posta_Grupo_05.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventario_Posta_Grupo_05.Services
{
    class EmpleadoService
    {
        private EmpleadoRepository empleadoRepository = new EmpleadoRepository();

        public bool Registrar(Empleado empleado)
        {
            if (empleadoRepository.Existe(empleado.Codigo))
            {
                return false;
            }
            else
            {
                empleadoRepository.Registrar(empleado);
                return true;
            }
        }

        public void Eliminar(int codigoEmpleado)
        {
            empleadoRepository.Eliminar(codigoEmpleado);
        }

        public void EliminarTodo()
        {
            empleadoRepository.EliminarTodo();
        }

        public List<Empleado> ListarTodo()
        {
            return EmpleadoRepository.ListarTodo();
        }

        public Empleado BuscarEmpleadoPorCodigo(int codigoEmpleado)
        {
            return empleadoRepository.BuscarEmpleadoPorCodigo(codigoEmpleado);
        }
    }
}
