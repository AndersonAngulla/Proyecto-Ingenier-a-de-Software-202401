﻿using Inventario_Posta_Grupo_05.Entities;
using Inventario_Posta_Grupo_05.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventario_Posta_Grupo_05.Services
{
    class InventarioService
    {
        private InventarioRepository inventarioRepository = new InventarioRepository();

        public bool Registrar(Inventario inventario)
        {
            if (inventarioRepository.Existe(inventario.Codigo))
            {
                return false;
            }
            else
            {
                inventarioRepository.Registrar(inventario);
                return true;
            }
        }

        public List<Inventario> ListarTodo()
        {
            return InventarioRepository.ListarTodo();
        }

        public Inventario BuscarInventarioPorCodigo(int codigoInventario)
        {
            return inventarioRepository.BuscarInventarioPorCodigo(codigoInventario);
        }

    }
}
