﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventario_Posta_Grupo_05.Entities
{
    class Empleado
    {
        public Empleado() { }
        public int Codigo { get; set; }
        public String Nombre { get; set; }
        public String Apellido { get; set; }
        public DateTime FechaIngreso { get; set; }
    }
}
