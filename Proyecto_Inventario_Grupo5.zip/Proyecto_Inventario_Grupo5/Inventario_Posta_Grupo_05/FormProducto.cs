﻿using Inventario_Posta_Grupo_05.Entities;
using Inventario_Posta_Grupo_05.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventario_Posta_Grupo_05
{
    public partial class FormProducto : Form
    {
        private int codigoInventario;
        private ProductoService productoService = new ProductoService();
        public FormProducto(int codigoInventario)
        {
            InitializeComponent();
            this.codigoInventario = codigoInventario;
            MostrarProductos(productoService.ListarTodo(codigoInventario));
        }

        private void MostrarProductos(List<Producto> productos)
        {
            dgListaProductos.DataSource = null;
            if (productos.Count == 0)
            {
                return;
            }
            else
            {
                dgListaProductos.DataSource = productos;
            }
        }

        private void LimpiarCampos()
        {
            tbCodigo.Clear();
            tbNombre.Clear();
            tbDescripcion.Clear();
            tbCantidadMalEstado.Clear();
            tbStock.Clear();
            cbCategoria.SelectedIndex = -1;
            cbEtiqueta.SelectedIndex = -1;
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpiarCampos_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void btnRegistrarInventario_Click(object sender, EventArgs e)
        {
            if (tbCodigo.Text == "" || tbNombre.Text == "" || tbDescripcion.Text == "" || tbCantidadMalEstado.Text == "" ||
                tbStock.Text == "" || cbCategoria.Text == "" || cbEtiqueta.Text == "")
            {
                MessageBox.Show("Por favor completar todos los campos", "Advertencia: Campo vacios", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (!int.TryParse(tbCodigo.Text, out int codigo))
            {
                MessageBox.Show("Se ha ingresado incorrectamente el campo Codigo", "Error: Campo Codigo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(tbCantidadMalEstado.Text, out int cantidadMalEstado))
            {
                MessageBox.Show("Se ha ingresado incorrectamente el campo Cantidad Mal Estado", "Error: Campo Cantidad Mal Estado", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(tbStock.Text, out int stock))
            {
                MessageBox.Show("Se ha ingresado incorrectamente el campo Stock", "Error: Campo Stock", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Producto producto = new Producto()
            {
                Codigo = int.Parse(tbCodigo.Text),
                Nombre = tbNombre.Text,
                Descripcion = tbDescripcion.Text,
                FechaIngreso = dtFechaIngreso.Value.Date,
                FechaCaducidad = dtFechaCaducidad.Value.Date,
                Categoria = cbCategoria.Text,
                Etiqueta = cbEtiqueta.Text,
                CantidadMalEstado = int.Parse(tbCantidadMalEstado.Text),
                Stock = int.Parse(tbStock.Text),
            };

            bool registrado = productoService.Registrar(codigoInventario, producto);
            if (!registrado)
            {
                MessageBox.Show("Se ha ingresado un código de producto ya existente", "Error: Codigo Existente", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MostrarProductos(productoService.ListarTodo(codigoInventario));
            LimpiarCampos();
        }

        private void LimpiarCamposStock()
        {
            tbCodigoStockSalida.Clear();
            tbSalidaStock.Clear();
        }


        private void btnActualizarStock_Click(object sender, EventArgs e)
        {
            int codigoProducto;
            int restarStock;

            if (tbCodigoStockSalida.Text == "" || tbSalidaStock.Text == "")
            {
                MessageBox.Show("Por favor completar todos los campos", "Advertencia: Campos Vacios", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (!int.TryParse(tbCodigoStockSalida.Text, out codigoProducto))
            {
                MessageBox.Show("Por favor ingrese un código de producto válido", "Error: Registrar Salida Stock", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(tbSalidaStock.Text, out restarStock))
            {
                MessageBox.Show("Por favor ingrese un stock válido", "Error: Registrar Salida Stock", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                DataGridViewRow fila = dgListaProductos.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => {
                    if (r.Cells["Codigo"].Value != null && int.TryParse(r.Cells["Codigo"].Value.ToString(), out int codigoEnCelda))
                    {
                        return codigoEnCelda == codigoProducto;
                    }
                    return false;
                });

                if (fila == null)
                {
                    throw new Exception("Producto no encontrado");
                }

                if (!int.TryParse(fila.Cells["Stock"].Value?.ToString(), out int stockActual))
                {
                    throw new Exception("Stock actual inválido");
                }

                if (restarStock > stockActual || restarStock <= 0)
                {
                    throw new Exception("La salida del stock no puede ser menor, mayor o nula al stock actual");
                }

                DialogResult result = MessageBox.Show("¿Seguro que desea registrar la salida de stock del producto?", "Informacion: Registrar Salida Stock", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

                if (result == DialogResult.OK)
                {
                    fila.Cells["Stock"].Value = stockActual - restarStock;
                    LimpiarCamposStock();
                    MessageBox.Show("Se ha registrado la salida del stock correctamente", "Información: Registrar Salida Stock", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al registrar la salida de stock: " + ex.Message, "Error: Registrar Salida Stock", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEliminarProducto_Click(object sender, EventArgs e)
        {
            if(dgListaProductos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor seleccionar el producto que desea eliminar", "Advertencia: Eliminacion Producto", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            string codigoProducto = dgListaProductos.SelectedRows[0].Cells[0].Value.ToString();
            productoService.Eliminar(int.Parse(codigoProducto));
            MostrarProductos(productoService.ListarTodo(codigoInventario));
        }
    }
}
