﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventario_Posta_Grupo_05.Entities
{
    class Inventario
    {
        public Inventario() { }
        public int Codigo { get; set; }
        public String Nombre { get; set; }
        public int Stock { get; set; }
        public String Proveedor { get; set; }
        public DateTime FechaEntrada { get; set; }
        public List<Producto> Productos { get; set; }
    }
}
