﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventario_Posta_Grupo_05.Entities
{
    class Producto
    {
        public Producto() { }
        public int Codigo { get; set; }
        public String Nombre { get; set; }
        public String Descripcion { get; set; }
        public DateTime FechaIngreso { get; set; }
        public DateTime FechaCaducidad { get; set; }
        public String Categoria { get; set; }
        public String Etiqueta { get; set; }
        public int CantidadMalEstado { get; set; }
        public int Stock { get; set; }
    }
}
