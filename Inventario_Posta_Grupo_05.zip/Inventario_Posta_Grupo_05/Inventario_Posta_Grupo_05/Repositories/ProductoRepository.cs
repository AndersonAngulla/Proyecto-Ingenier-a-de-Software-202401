﻿using Inventario_Posta_Grupo_05.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventario_Posta_Grupo_05.Repositories
{
    class ProductoRepository
    {
        public bool Existe(int codigoProducto)
        {
            List<Inventario> inventarios = InventarioRepository.ListarTodo();
            return inventarios.Exists(i => i.Productos.Exists(p => p.Codigo.Equals(codigoProducto)));
        }

        public void Registrar(int codigoInventario, Producto producto)
        {
            List<Inventario> inventarios = InventarioRepository.ListarTodo();
            Inventario inventario = inventarios.Find(p => p.Codigo.Equals(codigoInventario));
            inventario.Productos.Add(producto);
        }

        public List<Producto> ListarTodo(int codigoInventario)
        {
            List<Inventario> inventarios = InventarioRepository.ListarTodo();
            Inventario inventario = inventarios.Find(p => p.Codigo.Equals(codigoInventario));
            return inventario.Productos;
        }

        public void Eliminar(int codigoProducto)
        {
            List<Inventario> inventarios = InventarioRepository.ListarTodo();

            foreach (Inventario inventario in inventarios)
            {
                Producto inventarioAEliminar = inventario.Productos.FirstOrDefault(p => p.Codigo.Equals(codigoProducto));
                if (inventarioAEliminar != null)
                {
                    inventario.Productos.Remove(inventarioAEliminar);
                    break;
                }
            }
        }

        public Producto BuscarPorCodigo(int codigoProducto)
        {
            List<Inventario> inventarios = InventarioRepository.ListarTodo();

            foreach (Inventario inventario in inventarios)
            {

                Producto productoEncontrado = inventario.Productos.FirstOrDefault(p => p.Codigo == codigoProducto);
                if (productoEncontrado != null)
                {
                    return productoEncontrado;
                }
            }
            return null;
        }
    }
}
