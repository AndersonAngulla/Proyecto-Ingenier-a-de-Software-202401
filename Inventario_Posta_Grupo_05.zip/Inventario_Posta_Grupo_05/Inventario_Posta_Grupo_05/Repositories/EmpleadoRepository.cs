﻿using Inventario_Posta_Grupo_05.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventario_Posta_Grupo_05.Repositories
{
    class EmpleadoRepository
    {
        private static List<Empleado> empleados = new List<Empleado>();

        public bool Existe(int codigoEmpleado)
        {
            return empleados.Exists(e => e.Codigo.Equals(codigoEmpleado));
        }

        public void Registrar(Empleado empleado)
        {
            empleados.Add(empleado);
        }

        public void Eliminar(int codigoEmpleado)
        {
            empleados.RemoveAll(e => e.Codigo == codigoEmpleado);
        }

        public void EliminarTodo()
        {
            empleados.Clear();
        }

        public static List<Empleado> ListarTodo()
        {
            return empleados;
        }

        public Empleado BuscarEmpleadoPorCodigo(int codigoEmpleado)
        {
            return empleados.FirstOrDefault(e => e.Codigo == codigoEmpleado);
        }
    }
}
