﻿using Inventario_Posta_Grupo_05.Entities;
using Inventario_Posta_Grupo_05.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventario_Posta_Grupo_05
{
    public partial class FormEmpleado : Form
    {
        private EmpleadoService empleadoService = new EmpleadoService();

        public FormEmpleado()
        {
            InitializeComponent();
            MostrarEmpleados(empleadoService.ListarTodo());
        }

        private void MostrarEmpleados(List<Empleado> empleados)
        {
            dgListaAdministradores.DataSource = null;
            if(empleados.Count == 0)
            {
                return;
            }
            else
            {
                dgListaAdministradores.DataSource = empleados;
            }
        }

        private void LimpiarCampos()
        {
            tbCodigo.Clear();
            tbNombre.Clear();
            tbApellido.Clear();
            dtFechaIngreso.Value = DateTime.Now;
        }

        private void btnLimpiarCampos_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void btnEliminarAdministrador_Click(object sender, EventArgs e)
        {
            if (dgListaAdministradores.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor seleccionar el administrador que desea eliminar", "Advertencia: Eliminar Administrador", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            String codigoEmpleado = dgListaAdministradores.SelectedRows[0].Cells[0].Value.ToString();
            empleadoService.Eliminar(int.Parse(codigoEmpleado));
            MostrarEmpleados(empleadoService.ListarTodo());
        }

        private void btnEliminarAdministradores_Click(object sender, EventArgs e)
        {
            empleadoService.EliminarTodo();
            MostrarEmpleados(empleadoService.ListarTodo());
        }

        private void btnRegistrarAdministrador_Click(object sender, EventArgs e)
        {
            if (tbCodigo.Text == "" || tbNombre.Text == "" || tbApellido.Text == "")
            {
                MessageBox.Show("Por favor completar todos los campos", "Advertencia: Campo vacios", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (!int.TryParse(tbCodigo.Text, out int codigoEmpleado))
            {
                MessageBox.Show("Se ha ingresado incorrectamente el campo Codigo", "Error: Campo Codigo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            bool contieneNumeroNombre = false;

            foreach (char caracter in tbNombre.Text)
            {
                if (char.IsDigit(caracter))
                {
                    contieneNumeroNombre = true;
                    break;
                }
            }

            if (contieneNumeroNombre)
            {
                MessageBox.Show("Se ha ingresado incorrectamente el campo Nombre", "Error: Campo Nombre", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            bool contieneNumeroApellido = false;

            foreach (char caracter2 in tbApellido.Text)
            {
                if (char.IsDigit(caracter2))
                {
                    contieneNumeroApellido = true;
                    break;
                }
            }

            if (contieneNumeroApellido)
            {
                MessageBox.Show("Se ha ingresado incorrectamente el campo Apellido", "Error: Campo Apellido", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Empleado empleado = new Empleado
            {
                Codigo = int.Parse(tbCodigo.Text),
                Nombre = tbNombre.Text,
                Apellido = tbApellido.Text,
                FechaIngreso = dtFechaIngreso.Value.Date,
            };

            bool registrado = empleadoService.Registrar(empleado);
            if (!registrado)
            {
                MessageBox.Show("Se ha ingresado un código de administrador ya existente", "Error: Codigo Existente", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MostrarEmpleados(empleadoService.ListarTodo());
            LimpiarCampos();
        }

        private void btnBuscarCodigo_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbCodigoBuscar.Text))
            {
                MessageBox.Show("Por favor completar todos los campos", "Advertencia: Campos Vacios", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            int codigoABuscar;
            if (!int.TryParse(tbCodigoBuscar.Text, out codigoABuscar))
            {
                MessageBox.Show("El codigo del empleado debe ser un número entero válido", "Error: Codigo Empleado Buscar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Empleado empleadoEncontrado = empleadoService.BuscarEmpleadoPorCodigo(codigoABuscar);

            if (empleadoEncontrado != null)
            {
                ActualizarDataGridViewBusqueda(empleadoEncontrado);
            }
            else
            {
                MessageBox.Show("El codigo del empleado solicitado no se encuentra registrado", "Información: Codigo Empleado Buscar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        private void ActualizarDataGridViewBusqueda(Empleado empleado)
        {
            dgListaAdministradores.DataSource = null;
            List<Empleado> empleadosEncontrados = new List<Empleado>();
            empleadosEncontrados.Add(empleado);
            dgListaAdministradores.DataSource = empleadosEncontrados;
        }
    }
}
