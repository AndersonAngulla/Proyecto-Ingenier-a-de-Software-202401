﻿using Inventario_Posta_Grupo_05.Entities;
using Inventario_Posta_Grupo_05.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventario_Posta_Grupo_05
{
    public partial class FormInventario : Form
    {
        private InventarioService inventarioService = new InventarioService();

        public FormInventario()
        {
            InitializeComponent();
            MostrarInventarios(inventarioService.ListarTodo());
        }

        private void MostrarInventarios(List<Inventario> inventarios)
        {
            dgListaInventarios.DataSource = null;
            if(inventarios.Count == 0)
            {
                return;
            }
            else
            {
                dgListaInventarios.DataSource = inventarios;
            }
        }

        private void LimpiarCampos()
        {
            tbCodigo.Clear();
            tbNombre.Clear();
            tbStock.Clear();
            tbProveedor.Clear();
            dtFechaEntrada.Value = DateTime.Now;
        }

        private void btnLimpiarCampos_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void btnRegistrarInventario_Click(object sender, EventArgs e)
        {
            if(tbCodigo.Text == "" || tbNombre.Text == "" || tbStock.Text == "" || tbProveedor.Text == "")
            {
                MessageBox.Show("Por favor completar todos los campos", "Advertencia: Campo vacios", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if(!int.TryParse(tbCodigo.Text, out int codigo))
            {
                MessageBox.Show("Se ha ingresado incorrectamente el campo Codigo", "Error: Campo Codigo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(tbStock.Text, out int stock))
            {
                MessageBox.Show("Se ha ingresado incorrectamente el campo Stock", "Error: Campo Stock", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            bool contieneNumeroNombre = false;

            foreach (char caracter in tbNombre.Text)
            {
                if (char.IsDigit(caracter))
                {
                    contieneNumeroNombre = true;
                    break;
                }
            }

            if (contieneNumeroNombre)
            {
                MessageBox.Show("Se ha ingresado incorrectamente el campo Nombre", "Error: Campo Nombre", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Inventario inventario = new Inventario()
            {
                Codigo = int.Parse(tbCodigo.Text),
                Nombre = tbNombre.Text,
                Stock = int.Parse(tbStock.Text),
                Proveedor = tbProveedor.Text,
                FechaEntrada = dtFechaEntrada.Value.Date,
                Productos = new List<Producto>(),
            };

            bool registrado = inventarioService.Registrar(inventario);
            if (!registrado)
            {
                MessageBox.Show("Se ha ingresado un código de inventario ya existente", "Error: Codigo Existente", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MostrarInventarios(inventarioService.ListarTodo());
            LimpiarCampos();
        }

        private void btnVerProductos_Click(object sender, EventArgs e)
        {
            if(dgListaInventarios.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor seleccionar un inventario del cual desea ver los productos", "Advertencia: Ver Productos", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            String codigoInventario = dgListaInventarios.SelectedRows[0].Cells[0].Value.ToString();

            FormProducto formProducto = new FormProducto(int.Parse(codigoInventario));
            formProducto.Show();
        }

        private void LimpiarCamposStock()
        {
            tbCodigoActualizar.Clear();
            tbStockActualizar.Clear();
        }

        private void btnActualizarStock_Click(object sender, EventArgs e)
        {
            int codigoInventario;
            int nuevoStock;

            if (tbCodigoActualizar.Text == "" || tbStockActualizar.Text == "")
            {
                MessageBox.Show("Por favor completar todos los campos", "Advertencia: Campos Vacios", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (!int.TryParse(tbCodigoActualizar.Text, out codigoInventario))
            {
                MessageBox.Show("Por favor ingrese un código de inventario válido", "Error: Codigo Actualizar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(tbStockActualizar.Text, out nuevoStock))
            {
                MessageBox.Show("Por favor ingrese un stock válido", "Error: Stock Actualizar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                inventarioService.ActualizarStockInventario(codigoInventario, nuevoStock);
                DialogResult result = MessageBox.Show("¿Seguro que desea actualizar el stock del inventario?", "Informacion: Stock Actualizar", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

                if (result == DialogResult.OK)
                {
                    MostrarInventarios(inventarioService.ListarTodo());
                    LimpiarCamposStock();
                    MessageBox.Show("Se ha actualizado el stock correctamente", "Informacion: Stock Actualizar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar el stock: " + ex.Message, "Error: Stock Actualizar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
